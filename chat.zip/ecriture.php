<?php
session_start();
if (!isset($_SESSION['admin'])) {header ('Location: index.php');exit();}
?>
<html>
<head>
</head>
<body>
<?
$message = $_POST['message'];
$date = date("d/m/Y");
$heure = date("H:i:s");
$ligne ="\n"."$date"."-"."$heure"." : "."$message";
$fichier = fopen('messages.txt','r+');
rewind($fichier); 
$contenu1 = file_get_contents('messages.txt');
$contenu2 = $ligne.$contenu1;
rewind($fichier);
fputs($fichier,$contenu2);
fclose($fichier);
?>
<meta http-equiv="refresh" content="0;URL=accueil.php">
</body>
</html>
