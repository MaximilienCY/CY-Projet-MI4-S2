
<!-- ========================= DEBUT DE PAGE ============================= -->
<?php

ini_set('display_errors','off');
$c1=0; $c2=0;$c3=0;//drapeaux de tests de conditions
$f1= $_POST['connexion'];//récupération des valeurs 
$f2= $_POST['id_mf'];//saisies 
$f3= $_POST['mp_mf'];//dans le formulaire

//on vérifie que le visiteur a correctement saisi puis envoyé le formulaire
//echo md5($_POST['mp_mf']); //valeur md5 du mdp admin à placer dans connect.php
if (isset($f1) && $f1 == 'Connexion') {$c1=1;}
if ((isset($f2) && !empty($f2)) && (isset($f3) && !empty($f3))) {$c2=1;}
if ($f2=="toto" && $f3=="toto") {$c3=1;}


//si c1, c2, c3 sont ok, il s'agit de la secrétaire (profil admin)
if ($c1==1 && $c2==1 && $c3==1)
{
session_start();
$_SESSION['admin'] = $f2;
header('Location: accueil.php');
exit();	
}
else
{
echo "Saisie  incorrecte !  Erreur identifiant ou mot de passe !" ;
}
//---------------fin de la condition c1,c2, !c3----------------
?>

