<?php
session_start();
if (!isset($_SESSION['admin'])) {header ('Location: index.php');exit();}
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" href="style.css">
</head>
<body>
<form action="ecriture.php" method="post" autocomplete="off"> 
<fieldset>
<legend>NOUVEAU MESSAGE</legend>  
<input name="message" type="text" value=""><br/>
<input type="submit" name="Submit" class="btn_submit" value="Envoyer">
<input type="button" OnClick="javascript:window.location.reload()" value="Recevoir">
</fieldset>
</form>
<p>
<?
echo nl2br(file_get_contents("messages.txt"));
?>	
</p>
<hr>
</body>
</html>

