<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" href="style.css">
</head>
<body>
<p>
<form action="connexion.php" method="post" autocomplete="off">
  <fieldset>
    <legend>Espace privé</legend>
    Identifiant:<br>
    <input type="int" name="id_mf" value=""><br>
    Mot de passe:<br>
    <input type="password" name="mp_mf" value=""><br>
    <input type="submit" class="btn_submit" name="connexion" value="Connexion">
  </fieldset>
</form>
</p>
</body>
</html>

